package com.wipro.OrderMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
