package com.wipro.OrderMS.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.wipro.OrderMS.exception.ResourceNotFoundException;
import com.wipro.OrderMS.model.Order;
import com.wipro.OrderMS.repository.OrderRepository;

@Service
public class OrderService {

	@Autowired
	OrderRepository orderRepo;
	
	public Iterable<Order> getOrders(){
		return orderRepo.findAll();
	}
	
	public Order addOrder(Order order) {
		return orderRepo.save(order);	
	}
	
	public Order getOrder(Integer id) {
		return orderRepo.findById(id)
				.orElseThrow(()->new ResourceNotFoundException("Order not found with id = "+id));
	}
	
	public ResponseEntity<Order> deleteOrder(Integer id) {
		Order existing = orderRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Order not found with OrderID : " + id));
		orderRepo.delete(existing);
		return ResponseEntity.ok().build();
	}
	
	public Order updateOrder(Order order, Integer id) {
		Order existing = orderRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Order not found with OrderID : " + id));
		existing.setOrderID(order.getOrderID());
		existing.setProductID(order.getProductID());
		existing.setDeliveryAddress(order.getDeliveryAddress());
		return existing;
	}
}
