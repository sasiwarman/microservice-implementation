package com.wipro.OrderMS.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Order {

	@Id
	private int orderID;
	private String deliveryAddress;
	private int productID;
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Order(int orderID, String deliveryAddress, int productID) {
		super();
		this.orderID = orderID;
		this.deliveryAddress = deliveryAddress;
		this.productID = productID;
	}
	public int getOrderID() {
		return orderID;
	}
	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}
	public String getDeliveryAddress() {
		return deliveryAddress;
	}
	public void setDeliveryAddress(String deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}	
}
