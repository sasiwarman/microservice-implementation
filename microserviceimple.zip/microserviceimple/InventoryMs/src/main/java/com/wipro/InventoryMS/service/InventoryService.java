package com.wipro.InventoryMS.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.wipro.InventoryMS.exception.ResourceNotFoundException;
import com.wipro.InventoryMS.model.Inventory;
import com.wipro.InventoryMS.repository.InventoryRepository;

@Service
public class InventoryService {

	@Autowired
	InventoryRepository inventoryRepo;
	
	public Iterable<Inventory> getProducts(){
		return inventoryRepo.findAll();
	}
	
	public Inventory addProduct(Inventory invent) {
		return inventoryRepo.save(invent);	
	}
	
	public Inventory getProduct(Integer id) {
		return inventoryRepo.findById(id)
				.orElseThrow(()->new ResourceNotFoundException("product not found with id = "+id));
	}
	
	public ResponseEntity<Inventory> deleteProduct(Integer id) {
		Inventory existing = inventoryRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("product not found with productID : " + id));
		inventoryRepo.delete(existing);
		return ResponseEntity.ok().build();
	}
	
	public Inventory updateProduct(Inventory invent, Integer id) {
		Inventory existing = inventoryRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Product not found with ProductID : " + id));
		existing.setProductID(invent.getProductID());
		existing.setQuantity(invent.getQuantity());
		return existing;
	}
}
