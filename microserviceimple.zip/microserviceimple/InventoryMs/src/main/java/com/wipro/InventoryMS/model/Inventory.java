package com.wipro.InventoryMS.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Inventory {

	@Id
	private int productID;
	private int quantity;
	public Inventory() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Inventory(int productID, int quantity) {
		super();
		this.productID = productID;
		this.quantity = quantity;
	}
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}
