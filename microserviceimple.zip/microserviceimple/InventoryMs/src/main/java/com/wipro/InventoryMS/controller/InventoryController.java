package com.wipro.InventoryMS.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.InventoryMS.model.Inventory;
import com.wipro.InventoryMS.service.InventoryService;

@RestController
@RequestMapping("/inventory")
public class InventoryController {

	@Autowired
	InventoryService inventoryService;
	

	@GetMapping
	public Iterable<Inventory> getProducts(){
		Iterable<Inventory> product=inventoryService.getProducts();
		return product;
	}
	
	@PostMapping
	public Inventory addProduct(@RequestBody Inventory invent) {
		Inventory inventory=inventoryService.addProduct(invent);
		return inventory;
	}
	
	@GetMapping("{id}")
	public Inventory getProduct(@PathVariable Integer id) {
		Inventory inventory=inventoryService.getProduct(id);
		return inventory;
	}
	
	@PutMapping("{id}")
	public Inventory updateProduct(@RequestBody Inventory invent,@PathVariable Integer id) {
		Inventory inventory= inventoryService.updateProduct(invent, id);
		return inventory;
	}

	@DeleteMapping("/{Id}")
	public ResponseEntity<Inventory> deleteCustomer(@PathVariable Integer Id) {
		ResponseEntity<Inventory> response = inventoryService.deleteProduct(Id);
		return response;
	}
	
}
