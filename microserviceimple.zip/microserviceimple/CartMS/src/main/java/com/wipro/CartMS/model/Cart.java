package com.wipro.CartMS.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Cart {

	@Id
	private int cartID;
	private int productID;
	private String productName;
	private int price;
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cart(int cartID, int productID, String productName, int price) {
		super();
		this.cartID = cartID;
		this.productID = productID;
		this.productName = productName;
		this.price = price;
	}
	public int getCartID() {
		return cartID;
	}
	public void setCartID(int cartID) {
		this.cartID = cartID;
	}
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
}
