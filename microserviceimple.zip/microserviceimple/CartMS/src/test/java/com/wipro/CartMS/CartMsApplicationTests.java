package com.wipro.CartMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
